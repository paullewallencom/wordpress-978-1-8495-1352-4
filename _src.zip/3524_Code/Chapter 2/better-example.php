<?php
/*
Plugin Name: Better Example
Plugin URI: http://wordpress.org/#
Description: Undoing the Madness
Author: Everett's sometimes obnoxious Twin
Version: 0.7
Author URI: http://theonion.com/
*/

function safe_print() {
	print " -------- I think I'm getting a clue!";
}

/* End of File */